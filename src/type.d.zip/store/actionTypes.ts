export const OPEN_BUTTON = "OPEN_BUTTON"
export const CLOSE_BUTTON = "CLOSE_BUTTON"